﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Abhishek

{
    enum Mode
    {
        Flight = 100, Train = 50, Bus = 30
    }
    class Program
    {


        static void Main(string[] args)
        {
            Program p = new Program();
            p.Go();
            Console.ReadKey();
        }

        public void Go()
        {
            bool result = true;
            do {
                var values = Enum.GetValues(typeof(Mode));
                decimal sum = 0;
                decimal avg = 0;
                decimal totalTrips = 0;
                foreach (var v in values)
                {

                    string noOfTripsString = string.Empty;
                    int noOfTrips = 0;
                    do
                    {
                        Console.Write("The number of trips by {0} is ", v);
                        noOfTripsString = Console.ReadLine();
                        Thread.CurrentThread.CurrentCulture = new CultureInfo("it-IT", true);
                        Console.OutputEncoding = Encoding.UTF8;
                    }
                    while (!(int.TryParse(noOfTripsString, out noOfTrips) && (noOfTrips >= 0) && (noOfTrips <= 52)));

                    decimal price = noOfTrips * (int)v;
                    Console.WriteLine("The cost of each trip by a {0} is {1} and Bruno paid {2} for travelling by {3}", v, ((int)v).ToString("c"), price.ToString("c"), v);
                    sum += price;
                    totalTrips += noOfTrips;
                    avg = sum / totalTrips;
                }
                Console.WriteLine("The total expenditure for Bruno is {0}", sum.ToString("c"));
                Console.WriteLine("The average expenditure for Bruno is {0}", avg.ToString("c"));
                decimal euros = 1.00m;
                Console.WriteLine("Here, 1 Euro is shown as {0}", euros.ToString("c"));


                string answer = "n";
                do { Console.Write("do you want to repeat?");
                    answer = Console.ReadLine();
                } while (answer != "y" && answer != "n");
                switch (answer)
                {
                    case "y":
                        result = true;
                        break;
                    case "n":
                        result = false;
                        break;
                    default:
                        break;

                }
            } while ( result ); 
         }
    }          
    
}
